<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Site sobre mim</title>

    <!-- CSS  -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
<nav class="purple darken-4" role="navigation">
    <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo indigo-text text-lighten-2">Logo</>

    </div>
</nav>

<div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
        <div class="container">
            <br><br>
            <h1 class="header center indigo-text text-lighten-2">Reidner Rodrigues</h1>
            <div class="row center">
                <h5 class="header col s12 light indigo-text text-lighten-2">Um site sobre mim</h5>
            </div>
            <br><br>

        </div>
    </div>
    <div class="parallax"><img src="BackGround1.jpg" alt="Unsplashed background img 1"></div>
</div>


<div class="container blue darken-4">
    <div class="section">

        <!--   Icon Section   -->
        <div class="row">
            <div class="col s12 m4">
                <div class="icon-block">
                    <h2 class="center brown-text"><i class="material-icons white-text">person</i></h2>
                    <h5 class="center white-text">Informações</h5>

                    <p class="light white-text">Idade: 17 anos.</p>
                    <p class="light white-text">Moro em betim-mg.</p>
                    <p class="light white-text">Estudo no cotemig barroca, estou no 3ºano do ensino medio.</p>


                </div>
            </div>

            <div class="col s12 m4 ">
                <div class="icon-block">
                    <h2 class="center brown-text"><i class="material-icons white-text">personal_video</i></h2>
                    <h5 class="center white-text">Favoritos</h5>

                    <p class="light white-text">Anime: One Piece.</p>
                    <p class="light white-text">Serie: Doctor Who.</p>
                    <p class="light white-text">Jogo: Kingdom Hearts.</p>
                    <p class="light white-text"></p>
                </div>
            </div>

            <div class="col s12 m4">
                <div class="icon-block">
                    <h2 class="center brown-text"><i class="material-icons white-text">headset</i></h2>
                    <h5 class="center white-text">Musica</h5>

                    <p class="light white-text">Favorita: Angel With A Shotgun - The Cab.</p>
                    <p class="light white-text">Gênero: Indie.</p>
                    <p class="light white-text">Clipe: Alright - Stuck In The Sound.</p>
                    <p class="light white-text"></p></div>
            </div>
        </div>

    </div>
</div>


<div class="parallax-container valign-wrapper">
    <div class="section no-pad-bot">
        <div class="container">
            <div class="row center">
                <h5 class="header col s12 light">Pretenções para o futuro: ser designer grafico ou web designer</h5>
            </div>
        </div>
    </div>
    <div class="parallax"><img src="BackGround2.jpg" alt="Unsplashed background img 2"></div>
</div>

<div class="container">
    <div class="section">

        <div class="row">
            <div class="col s12 center">
                <h3><i class="mdi-content-send brown-text"></i></h3>
                <h4>Historia escolar</h4>
                <p class="left-align light">Quando eu era criança, eu fui para o jardim, rafael marinho, onde fiquei até ir para o primeiro ano, no primeiro ano fui para a escola, antônio de assis martins, onde conheci um de meus amigos que converso até hoje, Vitão, estudei lá até o 5º ano, pois no 6º ano, fui para o educare onde conheci a maioria de meus amigos, no educare eu estudei até o 9ºano e depois fui para o cotemig barroca, onde estou até hoje.</p>
            </div>
        </div>

    </div>
</div>


<div class="parallax-container valign-wrapper">
    <div class="section no-pad-bot">
        <div class="container">
            <div class="row center">
                <h5 class="header col s12 light">Fotos</h5>
            </div>
        </div>
    </div>
    <div class="parallax"><img src="BackGround3.jpg" alt="Unsplashed background img 3"></div>
</div>
<div class="container"
<div class="col s2 ">
    <div class="card-panel grey lighten-5 z-depth-1">
        <div class=" valign-wrapper">
            <div class="col s2">
                <img src="acampamento.jpg" alt="" class="z-depth-5 responsive-img">
            </div>
            <div class="col s2">
                <img src="aaaaa.jpeg." alt="" class="z-depth-5 responsive-img">
            </div>
            <div class="col s2">
                <img src="animefest.jpg" alt="" class="z-depth-5 responsive-img">
            </div>
            <div class="col s2">
                <img src="piramide.jpeg" alt="" class="z-depth-5 responsive-img">
            </div>
            <div class="col s2">
                <img src="sala.jpg.jpg" alt="" class="z-depth-5 responsive-img">
            </div>
            <div class="col s2">
                <img src="confusão.jpg" alt="" class="z-depth-5 responsive-img">
            </div>
            <div class="col s2">
                <img src="shopping.jpeg" alt="" class="z-depth-5 responsive-img">
            </div>
            <div class="col s2">
                <img src="carro.jpg" alt="" class="z-depth-5 responsive-img">
            </div>

        </div>
    </div>
</div>
</div>
<footer class="page-footer teal">
    <div class="footer-copyright">
        <div class="container">
            Made by <a class="brown-text text-lighten-3" href="http://materializecss.com">Materialize</a>
        </div>
    </div>
</footer>


<!--  Scripts-->
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="js/materialize.js"></script>
<script src="js/init.js"></script>

</body>
</html>
